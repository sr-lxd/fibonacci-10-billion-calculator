@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2019\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul
cl /nologo /utf-8 /O2 /W4 /I"C:\Users\lusun\mpir-win-src" /Fo"C:\Users\lusun\fib_publication_work\experiments_20261016\mpir_profile\profile.obj" "C:\Users\lusun\fib_publication_work\experiments_20261016\mpir_profile\fib_mpir_profile.c" /link /OUT:"C:\Users\lusun\fib_publication_work\experiments_20261016\mpir_profile\fib_mpir_profile.exe" /LIBPATH:"C:\Users\lusun\mpir-win-src\lib\x64\Release" mpir.lib
