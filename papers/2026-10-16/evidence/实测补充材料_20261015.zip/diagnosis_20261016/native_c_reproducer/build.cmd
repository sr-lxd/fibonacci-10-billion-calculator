@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2019\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul
cl /nologo /utf-8 /O2 /W4 /Fo"C:\Users\lusun\fib_publication_work\experiments_20261016\native_c_reproducer\gmp_square_minimal.obj" "C:\Users\lusun\fib_publication_work\gmp_square_minimal.c" /link /OUT:"C:\Users\lusun\fib_publication_work\experiments_20261016\native_c_reproducer\gmp_square_minimal.exe"
