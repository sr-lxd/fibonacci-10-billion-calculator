@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2019\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul
cl /nologo /utf-8 /O2 /W4  /I"C:\Users\lusun\fib_publication_work\experiments_20261016\followup\msys2\unpacked\mingw64\include" /Fo"C:\Users\lusun\fib_publication_work\experiments_20261016\followup\header_types\msys2.obj" "C:\Users\lusun\fib_publication_work\gmp_header_widths.c" /link /OUT:"C:\Users\lusun\fib_publication_work\experiments_20261016\followup\header_types\msys2_types.exe"
