@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2019\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul
cl /nologo /utf-8 /O2 /W4 /DPROBE_MPIR /I"C:\Users\lusun\mpir-win-src" /Fo"C:\Users\lusun\fib_publication_work\experiments_20261016\followup\header_types\mpir.obj" "C:\Users\lusun\fib_publication_work\gmp_header_widths.c" /link /OUT:"C:\Users\lusun\fib_publication_work\experiments_20261016\followup\header_types\mpir_types.exe"
