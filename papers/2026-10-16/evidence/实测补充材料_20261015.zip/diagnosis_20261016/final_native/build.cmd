@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2019\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul
cl /nologo /utf-8 /O2 /W4 /Fo"C:\Users\lusun\fib_publication_work\experiments_20261016\final_native\probe.obj" "C:\Users\lusun\fib_publication_work\experiments_20261016\final_native\gmp_final_probe.c" /link /OUT:"C:\Users\lusun\fib_publication_work\experiments_20261016\final_native\gmp_final_probe.exe"
