@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2019\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul
lib /nologo /def:"C:\Users\lusun\fib_publication_work\experiments_20261016\windows_gmp_profile\gmp.def" /machine:x64 /out:"C:\Users\lusun\fib_publication_work\experiments_20261016\windows_gmp_profile\gmp_import.lib"
if errorlevel 1 exit /b 1
cl /nologo /utf-8 /O2 /W4 /I"C:\Users\lusun\fib_publication_work\experiments_20261016\followup\msys2\unpacked\mingw64\include" /Fo"C:\Users\lusun\fib_publication_work\experiments_20261016\windows_gmp_profile\profile.obj" "C:\Users\lusun\fib_publication_work\experiments_20261016\windows_gmp_profile\fib_windows_gmp_profile.c" /link /OUT:"C:\Users\lusun\fib_publication_work\experiments_20261016\windows_gmp_profile\fib_windows_gmp_profile.exe" "C:\Users\lusun\fib_publication_work\experiments_20261016\windows_gmp_profile\gmp_import.lib"
