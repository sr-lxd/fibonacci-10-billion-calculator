from pathlib import Path
import hashlib,json,zipfile
from reproduce_windows_failure import ROOT,run_case

def main():
    wheel=next((ROOT/'wheels').glob('gmpy2-2.2.1-*.whl'))
    target=ROOT/'isolated_gmpy2_221';target.mkdir(exist_ok=True)
    with zipfile.ZipFile(wheel) as z:z.extractall(target)
    (ROOT/'wheel_provenance.json').write_text(json.dumps(dict(file=wheel.name,sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(),source='PyPI pip download --only-binary=:all: --no-deps gmpy2==2.2.1',isolated_target=str(target)),indent=2),encoding='utf-8')
    source=ROOT/'historical_v4_3.py'
    for rep in [1,2]:
        label=f'historical_gmpy2_221_8b_rep{rep}'
        if not (ROOT/label/'result.json').exists():run_case(source,8_000_000_000,'compute_only','auto',label,package=target)
    label='allocation_traced_231_8b'
    if not (ROOT/label/'result.json').exists():run_case(source,8_000_000_000,'compute_only','auto',label,trace=True)

if __name__=='__main__':main()
