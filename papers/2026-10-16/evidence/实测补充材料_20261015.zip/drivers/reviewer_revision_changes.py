"""Evidence-bound editorial changes, applied after measured source generation."""
from pathlib import Path
import csv,json,math

ROOT=Path(__file__).resolve().parent;REV=ROOT/'revision_20261015';EXP=ROOT/'experiments_20261015'
SCALE_CN='注：Native是在同一WSL2/Linux环境直接调用gmpy2.fib的1次对照，不计入2S-1/2/3的中位数、四分位数和图中误差线。各列独立保留2位小数；阶段和先由未舍入值相加再舍入，显示分项之和可相差0.01 s。峰值为累计RSS，额外fsync及核验另计。'
SCALE_EN='Note: Native is one direct gmpy2.fib control in the same WSL2/Linux environment. It is excluded from the 2S-1/2/3 medians, quartiles and figure error bars. Columns are rounded independently to two decimal places; stage sums use unrounded intervals, so adding displayed components can differ by 0.01 s. Peak is cumulative RSS; fsync and verification are separate.'
BENCH_CN='注：每种算法、每个规模各测5次，表中仅列中位数。Q1、Q3、IQR及范围见补充arithmetic_summary.csv；四分位数采用线性插值。'
BENCH_EN='Note: Five fresh-process trials per algorithm and scale; only medians appear here. Linearly interpolated Q1, Q3, IQR and ranges are supplied in arithmetic_summary.csv.'
MPIR_CN='保留的C源码与Python输出器均按十进制宽度二分拆分、缓存10的幂，并采用4,000,000位叶块；差异不在叶块上限。C版本调用MPIR的mpz_tdiv_qr和mpz_get_str，逐字符补零后用fwrite写出；Python版本调用GMP的f_divmod和digits，构造补零字符串后经Python文件对象写出。C版本还用一个接近完整结果宽度的10的幂校正位数并清空该次缓存；Python使用MPFR位数候选。发布EXE包含初始化、每10秒刷新的状态线程、位数校正、文件刷新与关闭。其日志记录整数运算约1分57秒结束，随后完成位数校正，至43分12秒结束全流程；不能把剩余耗时全部归于状态线程。Linux计时写入WSL2的/tmp，Windows输出位于C盘，两者文件系统路径与缓存条件不同。现有数据未分离库内除法和进制转换、补零、运行库I/O及磁盘等待，也未控制文件系统和缓存。因此，库实现、写出流程和存储路径是待检验因素，尚不能认定Windows磁盘或某一函数造成全部差异。上述源码检查不等同于对发布EXE作二进制匹配重建。'
MPIR_EN="The retained C and Python writers both bisect decimal widths, cache powers of ten and use 4,000,000-digit leaves; the leaf limit does not explain the gap. C calls MPIR mpz_tdiv_qr/mpz_get_str, pads zeros with fputc and writes with fwrite; Python uses GMP f_divmod/digits and writes padding strings through a Python file object. C also checks the width against a near-full-size power of ten and clears that cache; Python uses an MPFR width candidate. The release includes initialization, a ten-second status thread, width correction, file flushing and close. Its coarse log places arithmetic completion at about 1 min 57 s and total completion at 43 min 12 s, with width correction in between; the remaining time cannot all be assigned to progress reporting. Linux writes under WSL2 /tmp, whereas Windows writes to C:. Library division/conversion, padding, runtime I/O and disk waits were not profiled separately, and filesystem/cache conditions were not controlled. These are candidate factors, not measured causal explanations; source inspection is not a binary-matched rebuild of the release."
VALID_CN='新输出与直接库调用结果全文一致，模核验也通过了所检查的算术关系。这些结果属于一致性证据；直接对照与被测Linux路径共享GMP及既有递推原理，SHA-256相同也不单独证明数字正确，尚未获得独立实现或形式化证明。'
VALID_EN='Full output agrees with direct library evaluation, and modular checks satisfy the tested arithmetic relations. This is consistency evidence: the Linux paths share GMP and established identities, and matching SHA-256 digests do not independently prove numerical correctness. No independent implementation or formal correctness proof is provided.'

def apply_changes(text,name):
    cn=name=='joca'
    text=text.replace('Tables report medians and inclusive linearly interpolated quartiles;', 'Main tables report medians; supplementary arithmetic_summary.csv supplies inclusive linearly interpolated quartiles and ranges;')
    text=text.replace('报告中位数和线性插值四分位数，不据5次观测进行显著性推断。', '正文表列中位数，补充arithmetic_summary.csv列线性插值四分位数及范围，不据5次观测进行显著性推断。')
    text=text.replace('The newly generated native GMP file is compared byte by byte with the four complete repair-path outputs and the retained 2024 reference after removal of their documented headers and ASCII whitespace.', 'Primary byte comparisons use the new native GMP file and the four new repair-path outputs, removing documented headers and ASCII whitespace. Retained 2024 artifacts are compared separately for the historical audit.')
    for key,note in [('benchmark',BENCH_CN if cn else BENCH_EN),('scaling',SCALE_CN if cn else SCALE_EN)]:
        if note not in text:text=text.replace('@table '+key,'@table '+key+'\n\n'+note)
    if (MPIR_CN if cn else MPIR_EN) not in text:
        anchor='鉴于首轮MPIR转换耗时较长' if cn else 'The sampling protocol was amended after the first MPIR full-output run'
        assert anchor in text
        text=text.replace(anchor,(MPIR_CN if cn else MPIR_EN)+'\n\n'+anchor,1)
    # Historical provenance is retained in a separate audit, outside primary evidence.
    if cn:
        paragraphs=text.split('\n\n')
        for i,p in enumerate(paragraphs):
            if p.startswith('同时回查保留的2024年100亿.txt。'):
                paragraphs[i]='旧文件仅用于历史材料核查，不作为主要验证依据。其生成机器、原始命令及第三方来源仍未认证；完整核查记录见补充historical_provenance.md。'
        text='\n\n'.join(paragraphs)
    else:
        start=text.find('The historical file 100亿.txt, retained with modification time')
        if start!=-1:
            end=text.find('\n\n',start)
            assert end!=-1
            text=text[:start]+"Historical files are audited only for continuity with retained material and are not primary validation evidence. Their original machine, generation command and third-party provenance remain unauthenticated; details are supplied in historical_provenance.md."+text[end:]
        text=text.replace('and newly generated outputs are compared in full with a directly regenerated native GMP reference and with the qualified historical artifact.', 'and newly generated outputs are compared in full with direct native GMP evaluation; older artifacts are audited separately as historical material.')
    # The limitation belongs in the actual conclusion, not the abstract.
    heading='## 5 结语' if cn else ('## 7 Conclusion' if name=='arxiv' else '## Conclusions' if name=='peerj' else '## 5 Conclusions')
    start=text.index(heading);end=text.find('\n## ',start+len(heading))
    assert end!=-1
    caveat=VALID_CN if cn else VALID_EN
    if caveat not in text[start:end]:text=text[:end].rstrip()+'\n\n'+caveat+'\n\n'+text[end:]
    if cn:
        import build_manuscripts as b
        for old,new in sorted(b.CN_NUMBERS.items(),key=lambda x:len(x[0]),reverse=True):text=text.replace(old,new)
        for old,new in [('400万','400 万'),('三十二吉字节','32 GB'),('二十一亿位','21亿位'),('三十二','32'),('二吉字节','2 GiB'),('零和第一项','第0项和第1项'),('第零项','第0项'),('第一项','第1项')]:text=text.replace(old,new)
    return text

def write_evidence_tables():
    data=json.loads((EXP/'summary.json').read_text(encoding='utf-8'));rows=[]
    for g in data['groups']:
        if g['n'] not in [10**7,10**8,5*10**8,10**9] or g['algorithm'] not in ['native','doubling','lucas','two_squares'] or g['mode']!='compute_only':continue
        s=g['arithmetic_s'];rows.append(dict(n=g['n'],algorithm=g['algorithm'],count=g['count'],median_s=s['median'],q1_s=s['q1'],q3_s=s['q3'],iqr_s=s['q3']-s['q1'],min_s=s['min'],max_s=s['max']))
    assert len(rows)==16
    path=EXP/'arithmetic_summary.csv'
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    rounding=[]
    for m in data['raw_metrics']:
        if m['n']==10**10 and m['algorithm'] in ['native','two_squares'] and m['mode']=='full':
            assert math.isclose(m['arithmetic_s']+m['conversion_close_s'],m['arithmetic_conversion_s'],abs_tol=1e-8)
            rounding.append(dict(case=m['case'],arithmetic_s=m['arithmetic_s'],conversion_close_s=m['conversion_close_s'],sum_unrounded_s=m['arithmetic_conversion_s'],arithmetic_display=f'{m["arithmetic_s"]:.2f}',output_display=f'{m["conversion_close_s"]:.2f}',sum_display=f'{m["arithmetic_conversion_s"]:.2f}'))
    with (EXP/'rounding_audit.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rounding[0]));w.writeheader();w.writerows(rounding)
    print('ARITHMETIC_QUARTILES_AND_ROUNDING_VERIFIED',len(rows),len(rounding))

def render_architecture(directory,lang):
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyBboxPatch
    labels=(['输入下标与独立进程\nF(10^10)', 'WSL2：两平方3次，直接GMP对照1次\nWindows：MPIR完整输出1次', '十进制宽度二分拆分\n缓存10的幂；叶块上限4,000,000位', '完整数字文件\n每份2,089,876,403位', '全文比较、SHA-256与模核验\n一致性证据；非独立正确性证明'] if lang=='cn' else ['Index and isolated execution\nF(10^10)', 'WSL2: 3 two-square runs, 1 direct-GMP control\nWindows: 1 complete MPIR release run', 'Bisect decimal widths; cache powers of ten\nLeaf limit: 4,000,000 digits', 'Complete decimal payloads\n2,089,876,403 digits per file', 'Full byte comparison, SHA-256, modular checks\nConsistency evidence; no independent proof'])
    fig,ax=plt.subplots(figsize=(6.5,5.0));ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
    for i,label in enumerate(labels):
        y=.86-i*.19
        ax.add_patch(FancyBboxPatch((.04,y-.055),.92,.12,boxstyle='round,pad=0.008,rounding_size=0.008',linewidth=.9,edgecolor='#586b78',facecolor='#f5f6f7'))
        ax.text(.5,y+.005,label,ha='center',va='center',fontsize=15 if lang=='cn' else 13.5)
        if i<4:ax.annotate('',xy=(.5,y-.125),xytext=(.5,y-.065),arrowprops=dict(arrowstyle='->',lw=.9,color='#586b78'))
    fig.tight_layout(pad=.4)
    for ext in ['png','pdf','svg']:fig.savefig(directory/f'architecture_{lang}.{ext}',dpi=250,bbox_inches='tight')
    plt.close(fig)

if __name__=='__main__':
    write_evidence_tables()
    for name in ['joca','arxiv','softwarex','peerj']:
        p=REV/'sources'/(name+'.md');text=p.read_text(encoding='utf-8');p.write_text(apply_changes(text,name),encoding='utf-8')
