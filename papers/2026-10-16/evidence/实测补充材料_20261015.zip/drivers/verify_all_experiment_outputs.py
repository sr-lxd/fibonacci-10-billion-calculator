from __future__ import annotations

from itertools import zip_longest
from pathlib import Path
import hashlib,json,time

ROOT=Path(__file__).resolve().parent/'experiments_20261015'
N=2_089_876_403
CHUNK=8*1024*1024

def normalized(file,header):
    with file.open('rb') as f:
        if header is not None:
            actual=f.read(len(header));assert actual==header,(str(file),actual)
        buf=bytearray()
        while block:=f.read(CHUNK):
            block=block.translate(None,b' \t\r\n')
            assert not block or block.isdigit(),str(file)
            buf.extend(block)
            while len(buf)>=CHUNK:
                yield bytes(buf[:CHUNK]);del buf[:CHUNK]
        if buf:yield bytes(buf)

def main():
    files=[]
    for path in sorted(ROOT.glob('*/metrics.json')):
        metric=json.loads(path.read_text())
        if metric.get('n')==10**10 and metric.get('mode')=='full':
            files.append((path.parent/'output.txt',b'F(10000000000) = ' if metric['algorithm'].startswith('MPIR') else None,'new'))
    assert len(files)==5
    old=Path(r'D:\SoftWare\00陆旭东自编程序\斐波那契计算器')
    linux_header=(f'输入数字: 10000000000\n斐波那契值共 {N} 位。\n\n').encode('utf-8')
    # Original worker uses the host newline convention. The archived Linux file is LF.
    files.extend([(old/'100亿.txt',None,'historical_reference'),
                  (old/'F_10000000000_linux.txt',linux_header,'historical_linux'),
                  (old/'用家用电脑计算第100亿项斐波那契数列'/'F_stage.txt',b'F(10000000000) = ','historical_mpir')])
    hashes=[hashlib.sha256() for _ in files];counts=[0]*len(files);heads=[None]*len(files);tails=[b'']*len(files)
    start=time.perf_counter()
    for chunks in zip_longest(*(normalized(path,head) for path,head,_ in files)):
        assert all(c is not None for c in chunks),'unequal payload length'
        assert all(c==chunks[0] for c in chunks),'numeric payload mismatch'
        for i,c in enumerate(chunks):
            hashes[i].update(c);counts[i]+=len(c)
            if heads[i] is None:heads[i]=c[:50]
            tails[i]=c[-100:]
    assert all(n==N for n in counts)
    rows=[]
    for i,(path,head,kind) in enumerate(files):
        stat=path.stat()
        rows.append(dict(path=str(path),kind=kind,raw_bytes=stat.st_size,header_bytes=len(head or b''),
            mtime_local=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(stat.st_mtime)),digits=counts[i],
            sha256=hashes[i].hexdigest(),first50=heads[i].decode(),last100=tails[i].decode()))
    record=dict(date_local=time.strftime('%Y-%m-%d %H:%M:%S %z'),elapsed_s=time.perf_counter()-start,
        byte_for_byte_match=True,files=rows,normalization='Exact documented header removal; delete ASCII space/tab/CR/LF; reject all other non-digits; compare normalized streams in fixed 8 MiB blocks.',
        new_reference_case='linux_native_10b_reference',new_reference_status='Author-generated using a directly invoked Linux gmpy2.fib API; full runtime/command/environment record retained. Not third-party certification and not an independent library.',
        historical_provenance_status='Producer and supercomputer attribution from author history. Institutional profile verifies identity only. Original generation command, machine log, independent attestation and redistribution permission not obtained.')
    small=[]
    for path in sorted(ROOT.glob('*/metrics.json')):
        row=json.loads(path.read_text())
        if row.get('n')==10**9 and row.get('mode')=='full':
            small.append((path.parent/'output.txt',f'F({10**9}) = '.encode() if row['algorithm'].startswith('MPIR') else None,row))
    assert len(small)==6
    assert all(row['digits']==208987640 for _,_,row in small)
    assert len({row['sha256'] for _,_,row in small})==1
    small_count=0
    for chunks in zip_longest(*(normalized(p,h) for p,h,_ in small)):
        assert all(c is not None for c in chunks)
        assert all(c==chunks[0] for c in chunks)
        small_count+=len(chunks[0])
    assert small_count==208987640
    record['smaller_full_repetition_comparison']=dict(n=10**9,payloads=6,mpir_repetitions=5,native_gmp_reference_repetitions=1,digits=small_count,byte_for_byte_match=True,sha256=small[0][2]['sha256'],files=[str(p) for p,_,_ in small])
    (ROOT/'full_comparison_manifest.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(dict(files=len(files),digits=N,sha256=rows[0]['sha256'],elapsed_s=record['elapsed_s'],byte_for_byte_match=True),ensure_ascii=False))

if __name__=='__main__':main()
