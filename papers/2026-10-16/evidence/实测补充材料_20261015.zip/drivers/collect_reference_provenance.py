from __future__ import annotations
import ast,hashlib,json,time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
EXP=ROOT/'experiments_20261015'
OLD=Path(r'D:\SoftWare\00陆旭东自编程序\斐波那契计算器')

def main():
    rows=[]
    for path in sorted((OLD/'fib_sjc').glob('*.py')):
        raw=path.read_bytes();calls=[]
        try:
            tree=ast.parse(raw.decode('utf-8-sig'))
            for node in ast.walk(tree):
                if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='fibonacci':
                    if node.args and isinstance(node.args[0],ast.Constant):calls.append(node.args[0].value)
        except (SyntaxError,UnicodeDecodeError):pass
        rows.append(dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),mtime_local=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(path.stat().st_mtime)),literal_fibonacci_arguments=calls))
    result=dict(date_local=time.strftime('%Y-%m-%d %H:%M:%S %z'),institutional_identity_source='https://ipads.sjtu.edu.cn/zh/pub/members/jiacheng_shi/',
        identity_source_scope='Verifies Jiacheng Shi doctoral-student affiliation only, not production of the numeric reference.',
        historical_reference_path=str(OLD/'100亿.txt'),historical_reference_mtime=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime((OLD/'100亿.txt').stat().st_mtime)),
        candidate_source_files=rows,
        candidate_observation='The retained fibonacc_10b_sjc.py invokes fibonacci(1000000), despite its filename. It documents a matrix/multiprocessing implementation, not an authenticated ten-billion execution.',
        original_machine_job_log_found=False,original_generation_command_authenticated=False,third_party_attestation_obtained=False,
        redistribution_permission_documented=False,
        new_reference=dict(case='linux_native_10b_reference',generator_script='benchmark_linux.py',algorithm_argument='native',n=10**10,provenance='Author-generated during the current controlled record. Exact command, source identity, runtime and resources stored per trial. Not third-party certification.'),
        interpretation='File names, timestamps, institutional identity and numeric equality are distinct evidence. None alone authenticates the historical computing machine. Use the new documented generation chain for current verification.')
    note=Path(r'D:\lxd-1\24学年\第一学期\Sofia数智人版本更新记录.txt')
    raw=note.read_bytes();lines=raw.decode('utf-8-sig').splitlines()
    result['contemporaneous_author_record']=dict(path=str(note),sha256=hashlib.sha256(raw).hexdigest(),excerpt_line_numbers=[191,192,195,196],excerpt='\n'.join(f'{i}: {lines[i-1]}' for i in [191,192,195,196]),interpretation='The 2024-05-06 entry attributes matrix-power code to Jiacheng Shi; 2024-05-10 records an 18-hour computation. This author-maintained chronology does not identify the executing machine or authenticate the retained numeric file generation command.')
    (EXP/'reference_provenance_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print('PROVENANCE_AUDIT_WRITTEN',len(rows))

if __name__=='__main__':main()
