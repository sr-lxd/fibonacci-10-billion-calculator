from pathlib import Path
import json,time
import psutil

ROOT=Path(__file__).resolve().parent
matches=[]
for p in psutil.process_iter(['pid','name']):
    if p.info['name'] and p.info['name'].lower()=='python.exe':
        try:
            if str(ROOT/'run_repair_experiments.py') in p.cmdline() and p.status()!=psutil.STATUS_STOPPED:
                assert not p.children(),p.pid
                matches.append(p)
        except psutil.AccessDenied:pass
assert len(matches)==1,[p.pid for p in matches]
pid=matches[0].pid;matches[0].terminate()
(ROOT/'experiments_20261015'/'protocol_amendment_sampling.json').write_text(json.dumps(dict(
    timestamp=time.strftime('%Y-%m-%d %H:%M:%S %z'),terminated_waiting_supervisor_pid=pid,
    reason='Observed large MPIR conversion cost; target full output once, smaller full-output repeated trials and target-scale arithmetic repeats provide endpoint-specific evidence without redundant long output trials.',
    linux_full_target_repetitions=3,mpir_full_target_repetitions=1,mpir_full_1b_repetitions=5,
    mpir_compute_8b_repetitions=3,mpir_compute_10b_repetitions=3,
    current_numeric_process_preserved=True),indent=2),encoding='utf-8')
print('Waiting queue stopped safely',pid)
