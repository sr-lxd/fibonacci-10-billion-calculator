from __future__ import annotations

import argparse
import ctypes
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time
import winreg

import psutil

ROOT = Path(__file__).resolve().parent / 'experiments_20261015'

def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')

def load_source(path):
    spec = importlib.util.spec_from_file_location('fib_snapshot', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def child(args):
    # Suppress Windows crash-dialog UI; no allocation, algorithm or memory limit changes.
    ctypes.windll.kernel32.SetErrorMode(0x0001 | 0x0002 | 0x8000)
    if args.gmp_trace:
        from trace_gmp_alloc import install
        install(Path(args.case))
    mod = load_source(Path(args.source))
    if args.gmp_trace:
        from trace_gmp_alloc import verify_after_import
        verify_after_import()
    import gmpy2
    binary = Path(gmpy2.gmpy2.__file__)
    save(Path(args.case) / 'runtime.json', dict(
        python=sys.version, executable=sys.executable, gmpy2=gmpy2.version(),
        gmp=gmpy2.mp_version(), mpfr=gmpy2.mpfr_version(),
        pointer_bits=ctypes.sizeof(ctypes.c_void_p)*8,
        long_bits=ctypes.sizeof(ctypes.c_long)*8,
        binary_path=str(binary), binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
    ))
    return mod.worker_main(args.n, args.mode, args.backend,
                           str(Path(args.case)/'output.txt'), str(Path(args.case)/'diagnostic.log'))

def run_case(source, n, mode, backend, label, timeout=600, package=None, trace=False):
    case = ROOT / label
    case.mkdir(parents=True, exist_ok=False)
    cmd = [sys.executable, '-X', 'faulthandler', str(Path(__file__).resolve()),
           '--child', '--source', str(source), '--case', str(case), '--n', str(n),
           '--mode', mode, '--backend', backend]
    if trace:cmd.append('--gmp-trace')
    child_env={**os.environ,'PYTHONIOENCODING':'utf-8'}
    if package:
        child_env['PYTHONPATH']=str(package)
        child_env['FIB_GMP_PACKAGE']=str(package)
    start = time.perf_counter()
    peaks = dict(sampled_rss_bytes=0, sampled_private_bytes=0, os_peak_wset_bytes=0,
                 os_peak_pagefile_bytes=0)
    min_available = psutil.virtual_memory().available
    reason = None
    with (case/'stdout.jsonl').open('wb') as out, (case/'stderr.txt').open('wb') as err, (case/'memory.jsonl').open('w',encoding='utf-8',buffering=1) as samples:
        proc = subprocess.Popen(cmd, stdout=out, stderr=err,
            env=child_env, creationflags=subprocess.CREATE_NO_WINDOW)
        process = psutil.Process(proc.pid)
        while proc.poll() is None:
            elapsed=time.perf_counter()-start
            try:
                mi=process.memory_info()
                available=psutil.virtual_memory().available
                min_available=min(min_available,available)
                rec=dict(elapsed_s=elapsed,rss_bytes=mi.rss,private_bytes=mi.private,
                         peak_wset_bytes=mi.peak_wset,peak_pagefile_bytes=mi.peak_pagefile,
                         available_physical_bytes=available)
                peaks['sampled_rss_bytes']=max(peaks['sampled_rss_bytes'],mi.rss)
                peaks['sampled_private_bytes']=max(peaks['sampled_private_bytes'],mi.private)
                peaks['os_peak_wset_bytes']=max(peaks['os_peak_wset_bytes'],mi.peak_wset)
                peaks['os_peak_pagefile_bytes']=max(peaks['os_peak_pagefile_bytes'],mi.peak_pagefile)
                samples.write(json.dumps(rec)+'\n')
                if available < 3*2**30:
                    reason='guard_available_physical_below_3_GiB'
                    proc.kill()
                if elapsed > timeout:
                    reason='guard_timeout'
                    proc.kill()
            except (psutil.NoSuchProcess,psutil.AccessDenied):
                pass
            time.sleep(.05)
        rc=proc.wait()
    log=case/'diagnostic.log'
    lines=log.read_text(encoding='utf-8').splitlines() if log.exists() else []
    result=dict(label=label,n=n,mode=mode,backend=backend,pid=proc.pid,
                command=cmd,exit_code=rc,exit_hex=f'0x{rc & 0xffffffff:08X}',
                elapsed_s=time.perf_counter()-start,termination_guard=reason,
                sample_interval_s=.05,min_available_physical_bytes=min_available,
                **peaks,last_diagnostic=lines[-1] if lines else None,
                stderr=(case/'stderr.txt').read_text(encoding='utf-8',errors='replace'))
    save(case/'result.json',result)
    print(json.dumps(result,ensure_ascii=False),flush=True)
    return result

def main(args):
    ROOT.mkdir(exist_ok=True)
    source=ROOT/'historical_v4_3.py'
    original=Path(r'D:\SoftWare\00陆旭东自编程序\斐波那契计算器\斐波那契计算器v4.3.py')
    if not source.exists(): shutil.copy2(original,source)
    cpu=None
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,r'HARDWARE\DESCRIPTION\System\CentralProcessor\0') as key:
            cpu=winreg.QueryValueEx(key,'ProcessorNameString')[0]
    except OSError: pass
    save(ROOT/'environment_windows.json',dict(
        date_local=time.strftime('%Y-%m-%d %H:%M:%S %z'),platform=platform.platform(),cpu=cpu,
        physical_cores=psutil.cpu_count(logical=False),logical_cores=psutil.cpu_count(),
        memory=psutil.virtual_memory()._asdict(),swap=psutil.swap_memory()._asdict(),
        disk_C=shutil.disk_usage('C:/')._asdict(),python=sys.version,
        source_original=str(original),source_snapshot=str(source),
        source_sha256=hashlib.sha256(source.read_bytes()).hexdigest()))
    cases=[(100,'full','auto','sanity_100'),
           (1_000_000_000,'compute_only','auto','control_1b'),
           (8_000_000_000,'compute_only','auto','failure_8b_rep1'),
           (8_000_000_000,'compute_only','auto','failure_8b_rep2')]
    for n,mode,backend,label in cases:
        if (ROOT/label/'result.json').exists(): continue
        r=run_case(source,n,mode,backend,label)
        if r['termination_guard']: break

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--child',action='store_true')
    parser.add_argument('--gmp-trace',action='store_true')
    parser.add_argument('--source');parser.add_argument('--case')
    parser.add_argument('--n',type=int);parser.add_argument('--mode');parser.add_argument('--backend')
    args=parser.parse_args()
    sys.exit(child(args) if args.child else main(args))
