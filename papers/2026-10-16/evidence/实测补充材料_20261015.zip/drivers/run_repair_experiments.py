from __future__ import annotations
import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
import psutil

BASE=Path(__file__).resolve().parent
E=BASE/'experiments_20261015'
LIN='/tmp/fib_experiments_20261015'
def wslpath(p):return '/mnt/'+p.drive[0].lower()+p.as_posix()[2:]
def log(msg):print(time.strftime('%H:%M:%S'),msg,flush=True)
def run_linux(label,n,algorithm,mode):
    case=E/label
    if (case/'metrics.json').exists():return
    case.mkdir(exist_ok=True)
    lp=LIN+'/'+label
    # WSL can stop while native Windows trials are running; /tmp is ephemeral.
    # Initialize the parent before /usr/bin/time opens its output file.
    subprocess.run(['wsl.exe','-d','Ubuntu','--cd','/tmp','--exec','mkdir','-p',LIN],check=True,capture_output=True)
    prior=case/'command.json'
    if prior.exists() and json.loads(prior.read_text()).get('exit_code'):
        history=case/'failed_launcher_attempt';history.mkdir(exist_ok=True)
        for p in list(case.iterdir()):
            if p.is_file():shutil.copy2(p,history/p.name)
    cmd=['wsl.exe','-d','Ubuntu','--cd','/tmp','--exec','/usr/bin/time','-v','-o',lp+'_time.txt',
         'python3',wslpath(BASE/'benchmark_linux.py'),'--source',wslpath(E/'historical_v4_3.py'),
         '--directory',lp,'--n',str(n),'--algorithm',algorithm,'--mode',mode]
    log('START '+label)
    with (case/'stdout.jsonl').open('wb') as out,(case/'stderr.txt').open('wb') as err:
        proc=subprocess.Popen(cmd,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        start=time.perf_counter()
        while proc.poll() is None:
            if time.perf_counter()-start>1800:
                subprocess.run(['wsl.exe','-d','Ubuntu','--cd','/tmp','--exec','pkill','-f',lp],capture_output=True)
                proc.wait();break
            time.sleep(1)
        rc=proc.wait()
    (case/'command.json').write_text(json.dumps(dict(command=cmd,exit_code=rc,wall_s=time.perf_counter()-start),indent=2),encoding='utf-8')
    # Copy only completed evidence and outputs, retaining Linux originals.
    copycmd=['wsl.exe','-d','Ubuntu','--cd','/tmp','--exec','python3','-c',
       'import shutil,sys; from pathlib import Path; s=Path(sys.argv[1]); d=Path(sys.argv[2]); '+
       '[shutil.copy2(p,d/p.name) for p in s.iterdir() if p.is_file()]; shutil.copy2(str(s)+"_time.txt",d/"time_verbose.txt")',lp,wslpath(case)]
    cp=subprocess.run(copycmd,capture_output=True)
    if rc or cp.returncode:
        log('FAILED '+label+' '+str(rc)+' '+cp.stderr.decode(errors='replace'))
        raise RuntimeError(label)
    metrics=json.loads((case/'metrics.json').read_text())
    log('DONE '+label+' '+json.dumps({k:v for k,v in metrics.items() if k not in ['residue_checks']},ensure_ascii=False))

def run_mpir(label,n):
    case=E/label
    if (case/'metrics.json').exists():return
    case.mkdir(exist_ok=True)
    exe=Path(r'C:\Users\lusun\fibonacci-10-billion-calculator\fib_mpir_v1.1.0.exe')
    cmd=[str(exe),str(n),str(case/'output.txt')]
    log('START '+label)
    peak_rss=peak_private=0;start=time.perf_counter();minimum=psutil.virtual_memory().available
    with (case/'stdout.txt').open('wb') as out,(case/'stderr.txt').open('wb') as err,(case/'memory.jsonl').open('w',buffering=1) as samples:
        proc=subprocess.Popen(cmd,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        pp=psutil.Process(proc.pid)
        while proc.poll() is None:
            try:
                mi=pp.memory_info();avail=psutil.virtual_memory().available;minimum=min(minimum,avail)
                peak_rss=max(peak_rss,mi.peak_wset);peak_private=max(peak_private,mi.peak_pagefile)
                samples.write(json.dumps(dict(elapsed_s=time.perf_counter()-start,rss_bytes=mi.rss,private_bytes=mi.private,peak_wset_bytes=mi.peak_wset,peak_pagefile_bytes=mi.peak_pagefile,available_bytes=avail))+'\n')
                if avail<3*2**30:proc.kill();raise RuntimeError('Available memory guard triggered')
            except psutil.NoSuchProcess:pass
            if time.perf_counter()-start>7200:proc.kill();raise RuntimeError('Timeout')
            time.sleep(.05)
        rc=proc.wait()
    duration=time.perf_counter()-start
    assert rc==0,(label,rc)
    output=case/'output.txt';h=hashlib.sha256();count=0;head=b'';tail=b''
    prefix=f'F({n}) = '.encode()
    with output.open('rb') as f:
        assert f.read(len(prefix))==prefix
        while chunk:=f.read(8*1024*1024):
            chunk=chunk.rstrip(b'\r\n');assert chunk.isdigit()
            if not head:head=chunk[:50]
            tail=chunk[-100:];h.update(chunk);count+=len(chunk)
    metrics=dict(n=n,mode='full',algorithm='MPIR_release_v1.1.0',
        process_wall_s=duration,os_peak_wset_bytes=peak_rss,os_peak_pagefile_bytes=peak_private,
        min_available_physical_bytes=minimum,sample_interval_s=.05,exit_code=rc,
        digits=count,sha256=h.hexdigest(),first50=head.decode(),last100=tail.decode(),
        binary_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),command=cmd)
    (case/'metrics.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
    log('DONE '+label+' '+json.dumps(metrics))

def main():
    first=E/'windows_mpir_10b_full_rep1'
    amendment=first/'supervisor_amendment.json'
    if amendment.exists() and not (first/'metrics.json').exists():
        supervisor=json.loads(amendment.read_text())['old_supervisor_pid']
        log('WAITING for preserved MPIR trial under the amended supervisor')
        while not (first/'metrics.json').exists():
            if not psutil.pid_exists(supervisor):raise RuntimeError('Adopted trial stopped before recording metrics')
            time.sleep(1)
        time.sleep(2)
    subprocess.run(['wsl.exe','-d','Ubuntu','--cd','/tmp','--exec','mkdir','-p',LIN],check=True)
    # All CPU-intensive trials are sequential. Interleave algorithm order by repeat.
    algs=['native','two_squares','lucas','doubling']
    for n in [10**7,10**8,5*10**8,10**9]:
        for rep in range(5):
            order=algs[rep%4:]+algs[:rep%4]
            for alg in order:run_linux(f'linux_{alg}_{n}_rep{rep+1}',n,alg,'compute_only')
    for rep in range(3):
        run_linux(f'linux_two_squares_8b_rep{rep+1}',8*10**9,'two_squares','compute_only')
    for rep in range(3):
        run_linux(f'linux_two_squares_10b_full_rep{rep+1}',10**10,'two_squares','full')
        if rep==0:run_mpir('windows_mpir_10b_full_rep1',10**10)
    run_linux('linux_native_10b_reference',10**10,'native','full')
    for rep in range(5):run_mpir(f'windows_mpir_1b_full_rep{rep+1}',10**9)
    subprocess.run([sys.executable,str(BASE/'benchmark_mpir_compute.py')],check=True)
    log('ALL_REPAIR_EXPERIMENTS_COMPLETED')

if __name__=='__main__':main()
