from __future__ import annotations
from collections import defaultdict
import csv,hashlib,json,statistics
from pathlib import Path

ROOT=Path(__file__).resolve().parent/'experiments_20261015'
def stats(values):
    values=sorted(values)
    q=statistics.quantiles(values,n=4,method='inclusive') if len(values)>=2 else [values[0]]*3
    return dict(count=len(values),median=statistics.median(values),q1=q[0],q3=q[2],min=values[0],max=values[-1])
def main():
    rows=[];groups=defaultdict(list)
    for path in sorted(ROOT.glob('*/metrics.json')):
        row=json.loads(path.read_text(encoding='utf-8'));row['case']=path.parent.name
        rows.append(row);groups[(row['n'],row['algorithm'],row['mode'])].append(row)
    summary=[]
    fields=['arithmetic_s','conversion_close_s','arithmetic_conversion_s','explicit_fsync_s',
            'process_wall_s','arithmetic_peak_rss_bytes','full_peak_rss_bytes','os_peak_wset_bytes','os_peak_pagefile_bytes']
    for (n,alg,mode),items in sorted(groups.items()):
        summary.append(dict(n=n,algorithm=alg,mode=mode,count=len(items),
            **{f:stats([r[f] for r in items if f in r]) for f in fields if any(f in r for r in items)}))
    failures=[]
    for path in sorted(ROOT.glob('*/result.json')):
        row=json.loads(path.read_text(encoding='utf-8'));row['runtime']=json.loads((path.parent/'runtime.json').read_text(encoding='utf-8')) if (path.parent/'runtime.json').exists() else None
        failures.append(row)
    obj=dict(groups=summary,raw_metrics=rows,windows_trials=failures)
    (ROOT/'summary.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    columns=['case','n','algorithm','mode']+fields+['digits','sha256']
    with (ROOT/'raw_measurements.csv').open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=columns,extrasaction='ignore');writer.writeheader();writer.writerows(rows)
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
