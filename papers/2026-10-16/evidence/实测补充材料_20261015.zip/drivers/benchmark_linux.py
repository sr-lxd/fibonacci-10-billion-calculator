from __future__ import annotations
import argparse, hashlib, importlib.util, json, os, platform, resource, sys, time
from pathlib import Path
import gmpy2

def save(path,obj): Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def load(path):
    spec=importlib.util.spec_from_file_location('fib_original',path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def doubling(n):
    a,b=gmpy2.mpz(0),gmpy2.mpz(1)
    for bit in bin(n)[2:]:
        c=a*((b<<1)-a);d=a*a+b*b
        a,b=(c,d) if bit=='0' else (d,c+d)
    return a
def modfib(n,p):
    a,b=0,1
    for bit in bin(n)[2:]:
        c=a*(2*b-a)%p;d=(a*a+b*b)%p
        a,b=(c,d) if bit=='0' else (d,(c+d)%p)
    return a
def main(a):
    m=load(a.source);outdir=Path(a.directory);outdir.mkdir(exist_ok=True,parents=True)
    info=dict(python=sys.version,platform=platform.platform(),gmpy2=gmpy2.version(),gmp=gmpy2.mp_version(),mpfr=gmpy2.mpfr_version(),
        cpuinfo=Path('/proc/cpuinfo').read_text(),meminfo=Path('/proc/meminfo').read_text(),
        source_sha256=hashlib.sha256(Path(a.source).read_bytes()).hexdigest(),
        uname=list(os.uname()),date_local=time.strftime('%Y-%m-%d %H:%M:%S %z'),
        pointer_bytes=__import__('struct').calcsize('P'),long_bytes=__import__('struct').calcsize('l'))
    save(outdir/'environment.json',info)
    algorithms={'native':gmpy2.fib,'two_squares':m.fib_two_squares,'lucas':m.fib_lucas,'doubling':doubling}
    start=time.perf_counter();value=algorithms[a.algorithm](a.n);arithmetic=time.perf_counter()-start
    arithmetic_peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024
    primes=[1_000_000_007,1_000_000_009,2_147_483_647,10**100]
    residues=[dict(modulus=str(p),expected=str(modfib(a.n,p)),observed=str(value%p)) for p in primes]
    assert all(r['expected']==r['observed'] for r in residues)
    result=dict(n=a.n,algorithm=a.algorithm,mode=a.mode,arithmetic_s=arithmetic,
        bits=value.bit_length(),arithmetic_peak_rss_bytes=arithmetic_peak,residue_checks=residues)
    print(json.dumps(dict(event='arithmetic_done',**result)),flush=True)
    if a.mode=='full':
        width=m.fib_digits(a.n)
        start=time.perf_counter()
        output=outdir/'output.txt'
        with output.open('w',encoding='ascii',newline='\n') as f:
            m._write_dec(f,value,width,{})
        result['conversion_close_s']=time.perf_counter()-start
        result['output_bytes']=output.stat().st_size
        result['full_peak_rss_bytes']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024
        start=time.perf_counter()
        with output.open('rb') as f:os.fsync(f.fileno())
        result['explicit_fsync_s']=time.perf_counter()-start
        result['arithmetic_conversion_s']=arithmetic+result['conversion_close_s']
        del value
        h=hashlib.sha256();count=0;head=b'';tail=b''
        start=time.perf_counter()
        with output.open('rb') as f:
            while chunk:=f.read(8*1024*1024):
                assert chunk.isdigit()
                h.update(chunk);count+=len(chunk)
                if not head:head=chunk[:50]
                tail=chunk[-100:]
        assert count==width and head[:1]!=b'0'
        result.update(sha256=h.hexdigest(),digits=count,first50=head.decode(),last100=tail.decode(),verification_s=time.perf_counter()-start)
    save(outdir/'metrics.json',result)
    print(json.dumps(dict(event='finished',**result)),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--directory',required=True)
    p.add_argument('--algorithm',required=True);p.add_argument('--mode',default='compute_only');p.add_argument('--n',type=int,required=True)
    main(p.parse_args())
