"""Replace only our experiment supervisor while preserving its live MPIR child.

Protocol amendment: the original 30-minute controller timeout is inadequate.
Suspend that controller, maintain a new sampler/guard, and terminate only that
controller after the numeric program has exited and its measurements are saved.
"""
from __future__ import annotations
import hashlib,json,sys,time
from pathlib import Path
import psutil

ROOT=Path(__file__).resolve().parent
CASE=ROOT/'experiments_20261015'/'windows_mpir_10b_full_rep1'

def main():
    candidates=[]
    for p in psutil.process_iter(['pid','name']):
        if p.info['name'].lower()=='fib_mpir_v1.1.0.exe':
            try:
                if str(CASE/'output.txt') in p.cmdline():candidates.append(p)
            except psutil.Error:pass
    assert len(candidates)==1,[p.pid for p in candidates]
    child=candidates[0];parent=child.parent()
    assert str(ROOT/'run_repair_experiments.py') in parent.cmdline(),parent.pid
    cmd=child.cmdline();start_epoch=child.create_time();parent_cmd=parent.cmdline()
    oldlast=json.loads((CASE/'memory.jsonl').read_text().splitlines()[-1])
    oldpeak=json.loads((CASE/'memory.jsonl').read_text().splitlines()[0])
    peak_rss=max(oldlast['peak_wset_bytes'],oldpeak['peak_wset_bytes'])
    peak_private=max(oldlast['peak_pagefile_bytes'],oldpeak['peak_pagefile_bytes'])
    minimum=oldlast['available_bytes']
    amendment=dict(reason='Original supervisor had a 1800 s timeout; collection supervisor replaced without restarting or changing numeric child.',child_pid=child.pid,child_create_time=start_epoch,old_supervisor_pid=parent.pid,old_supervisor_command=parent_cmd,new_supervisor_started=time.time(),sample_interval_s=.05,clock='OS process creation timestamp to observed termination; up to 50 ms polling delay',numeric_process_unchanged=True)
    (CASE/'supervisor_amendment.json').write_text(json.dumps(amendment,indent=2),encoding='utf-8')
    parent.suspend()
    print('ADOPTED',child.pid,'SUPERVISOR_SUSPENDED',parent.pid,flush=True)
    try:
        with (CASE/'memory_adopted.jsonl').open('w',buffering=1) as samples:
            last_report=time.monotonic()
            while True:
                try:
                    rc=child.wait(timeout=.05)
                    break
                except psutil.TimeoutExpired:pass
                try:
                    mi=child.memory_info();available=psutil.virtual_memory().available;minimum=min(minimum,available)
                    peak_rss=max(peak_rss,mi.peak_wset);peak_private=max(peak_private,mi.peak_pagefile)
                    samples.write(json.dumps(dict(elapsed_s=time.time()-start_epoch,rss_bytes=mi.rss,private_bytes=mi.private,peak_wset_bytes=mi.peak_wset,peak_pagefile_bytes=mi.peak_pagefile,available_bytes=available))+'\n')
                    if available<3*2**30:child.kill();raise RuntimeError('Physical memory guard')
                except psutil.NoSuchProcess:
                    rc=child.wait();break
                if time.time()-start_epoch>7200:child.kill();raise RuntimeError('Amended 7200s timeout')
                if time.monotonic()-last_report>=60:
                    print('RUNNING',round(time.time()-start_epoch,1),'s',round(peak_rss/2**30,2),'GiB peak',flush=True);last_report=time.monotonic()
        duration=time.time()-start_epoch
        assert rc==0,rc
        output=CASE/'output.txt';h=hashlib.sha256();count=0;head=b'';tail=b''
        with output.open('rb') as f:
            assert f.read(17)==b'F(10000000000) = '
            while c:=f.read(8*1024*1024):
                c=c.rstrip(b'\r\n');assert c.isdigit()
                h.update(c);count+=len(c)
                if not head:head=c[:50]
                tail=c[-100:]
        assert count==2089876403
        result=dict(n=10**10,mode='full',algorithm='MPIR_release_v1.1.0',process_wall_s=duration,
            os_peak_wset_bytes=peak_rss,os_peak_pagefile_bytes=peak_private,min_available_physical_bytes=minimum,
            sample_interval_s=.05,exit_code=rc,digits=count,sha256=h.hexdigest(),first50=head.decode(),last100=tail.decode(),
            binary_sha256=hashlib.sha256(Path(cmd[0]).read_bytes()).hexdigest(),command=cmd,supervisor_amendment='See supervisor_amendment.json; original numeric process continuously preserved.')
        (CASE/'metrics.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
        print('DONE',json.dumps(result),flush=True)
    finally:
        # Never terminate an unknown process or the numeric child here.
        if parent.is_running() and str(ROOT/'run_repair_experiments.py') in parent.cmdline():
            parent.terminate()

if __name__=='__main__':main()
