from __future__ import annotations
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
import psutil

BASE=Path(__file__).resolve().parent
EXP=BASE/'experiments_20261015'
BUILD=EXP/'instrumented_mpir'

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def build():
    BUILD.mkdir(exist_ok=True)
    original=BASE/'package'/'共同材料'/'fib_mpir_v1_1_0.c'
    text=original.read_text(encoding='utf-8-sig')
    needle='    fibonacci_two_squares(n, result);'
    assert text.count(needle)==1
    replacement='''    LARGE_INTEGER bench_freq, bench_start, bench_end;
    QueryPerformanceFrequency(&bench_freq);
    QueryPerformanceCounter(&bench_start);
    fibonacci_two_squares(n, result);
    QueryPerformanceCounter(&bench_end);
    if (getenv("FIB_BENCH_COMPUTE_ONLY") != NULL) {
        printf("BENCH_JSON {\\\"n\\\":%" PRIu64 ",\\\"arithmetic_s\\\":%.9f,\\\"bits\\\":%zu,\\\"residue_1000000007\\\":%lu,\\\"residue_1000000009\\\":%lu,\\\"residue_2147483647\\\":%lu,\\\"limb_bytes\\\":%zu,\\\"mp_size_bytes\\\":%zu}\\n",
               n, (double)(bench_end.QuadPart-bench_start.QuadPart)/(double)bench_freq.QuadPart,
               mpz_sizeinbase(result, 2), mpz_fdiv_ui(result, 1000000007UL),
               mpz_fdiv_ui(result, 1000000009UL), mpz_fdiv_ui(result, 2147483647UL),
               sizeof(mp_limb_t), sizeof(mp_size_t));
        exit_code = 0;
        goto cleanup;
    }'''
    source=BUILD/'fib_mpir_instrumented.c';source.write_text(text.replace(needle,replacement),encoding='utf-8',newline='\n')
    vc=Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2019\BuildTools\VC\Auxiliary\Build\vcvars64.bat')
    include=Path(r'C:\Users\lusun\mpir-win-src');lib=include/'lib'/'x64'/'Release'/'mpir.lib'
    exe=BUILD/'fib_mpir_compute.exe'
    manifest=BUILD/'build_manifest.json'
    if exe.exists() and manifest.exists():
        prior=json.loads(manifest.read_text(encoding='utf-8'))
        if prior['instrumented_source_sha256']==digest(source) and prior['static_library_sha256']==digest(lib) and prior['binary_sha256']==digest(exe):
            print('REUSING_VERIFIED_BUILD',prior['binary_sha256'],flush=True)
            return exe
    command='@echo off\r\ncall "'+str(vc)+'"\r\ncl /nologo /utf-8 /O2 /W4 /I"'+str(include)+'" /Fo"'+str(BUILD/'fib_mpir_compute.obj')+'" "'+str(source)+'" /link /OUT:"'+str(exe)+'" /LIBPATH:"'+str(lib.parent)+'" mpir.lib\r\n'
    script=BUILD/'build_compute.cmd';script.write_bytes(command.encode('utf-8'))
    content=script.read_bytes();assert not content.startswith(b'\xef\xbb\xbf') and content.count(b'\n')==content.count(b'\r\n')
    r=subprocess.run(['cmd.exe','/d','/c',str(script)],capture_output=True,cwd=BUILD)
    (BUILD/'build_stdout.txt').write_bytes(r.stdout);(BUILD/'build_stderr.txt').write_bytes(r.stderr)
    assert r.returncode==0,r.stdout.decode(errors='replace')+r.stderr.decode(errors='replace')
    (BUILD/'build_manifest.json').write_text(json.dumps(dict(original_source=str(original),original_sha256=digest(original),instrumented_source_sha256=digest(source),binary_sha256=digest(exe),static_library=str(lib),static_library_sha256=digest(lib),compiler_environment=str(vc),flags='/utf-8 /O2 /W4 x64',modification='QueryPerformanceCounter around existing fibonacci_two_squares; compute-only environment branch after arithmetic; original recurrence and arithmetic function unchanged.',batch_CRLF_verified=True),indent=2),encoding='utf-8')
    return exe

def modfib(n,p):
    a,b=0,1
    for bit in bin(n)[2:]:
        c=a*(2*b-a)%p;d=(a*a+b*b)%p
        a,b=(c,d) if bit=='0' else (d,(c+d)%p)
    return a

def run(exe,n,rep):
    label=f'windows_mpir_compute_{n}_rep{rep}'
    case=EXP/label
    if (case/'metrics.json').exists():return
    case.mkdir(exist_ok=True)
    cmd=[str(exe),str(n),str(case/'not_written.txt')]
    peak_rss=peak_private=0;minimum=psutil.virtual_memory().available;start=time.perf_counter()
    with (case/'stdout.txt').open('wb') as out,(case/'stderr.txt').open('wb') as err,(case/'memory.jsonl').open('w',buffering=1) as samples:
        proc=subprocess.Popen(cmd,stdout=out,stderr=err,env={**os.environ,'FIB_BENCH_COMPUTE_ONLY':'1'},creationflags=subprocess.CREATE_NO_WINDOW)
        pp=psutil.Process(proc.pid)
        while proc.poll() is None:
            try:
                m=pp.memory_info();available=psutil.virtual_memory().available;minimum=min(minimum,available)
                peak_rss=max(peak_rss,m.peak_wset);peak_private=max(peak_private,m.peak_pagefile)
                samples.write(json.dumps(dict(elapsed_s=time.perf_counter()-start,rss_bytes=m.rss,private_bytes=m.private,peak_wset_bytes=m.peak_wset,peak_pagefile_bytes=m.peak_pagefile,available_bytes=available))+'\n')
                if available<3*2**30:proc.kill();raise RuntimeError('Available-memory guard')
            except psutil.NoSuchProcess:pass
            if time.perf_counter()-start>1200:proc.kill();raise RuntimeError('Timeout')
            time.sleep(.05)
        rc=proc.wait()
    assert rc==0,(label,rc)
    lines=(case/'stdout.txt').read_text(encoding='utf-8',errors='replace').splitlines()
    row=json.loads(next(line.removeprefix('BENCH_JSON ') for line in lines if line.startswith('BENCH_JSON ')))
    for p in [1_000_000_007,1_000_000_009,2_147_483_647]:assert row[f'residue_{p}']==modfib(n,p)
    row.update(algorithm='MPIR_instrumented_compute',mode='compute_only',process_wall_s=time.perf_counter()-start,
               os_peak_wset_bytes=peak_rss,os_peak_pagefile_bytes=peak_private,min_available_physical_bytes=minimum,
               sample_interval_s=.05,binary_sha256=digest(exe),command=cmd,exit_code=rc)
    (case/'metrics.json').write_text(json.dumps(row,indent=2),encoding='utf-8')
    print('MPIR_COMPUTE_DONE',label,json.dumps(row),flush=True)

def main():
    from run_repair_experiments import run_linux
    run_linux('linux_native_1b_reference',10**9,'native','full')
    exe=build()
    run(exe,100,1)
    for n in [8*10**9,10**10]:
        for rep in range(1,4):run(exe,n,rep)

if __name__=='__main__':
    import sys
    if '--build-only' in sys.argv:
        executable=build();run(executable,100,1)
    else:main()
